ArrayMaker v2.58
Note: This version has a new parameter in the "motor.cfg" file for a separate
acceleration value for the x-stage during test prints. This value should be entered
on the 19th line of your "motor.cfg" file, inserted between the "HPrintZ" line and the
"SpeedX" line.
See the example file if you are unsure.
